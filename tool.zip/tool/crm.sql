/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50539
Source Host           : localhost:3306
Source Database       : crm

Target Server Type    : MYSQL
Target Server Version : 50539
File Encoding         : 65001

Date: 2016-09-28 17:06:27
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for customer_care
-- ----------------------------
DROP TABLE IF EXISTS `customer_care`;
CREATE TABLE `customer_care` (
  `care_id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) DEFAULT NULL,
  `care_theme` varchar(50) DEFAULT NULL,
  `care_way` varchar(50) DEFAULT NULL,
  `care_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `care_remark` varchar(1000) DEFAULT NULL,
  `care_nexttime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `care_people` varchar(50) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`care_id`),
  KEY `FK_Reference_15` (`customer_id`),
  CONSTRAINT `FK_Reference_15` FOREIGN KEY (`customer_id`) REFERENCES `customer_info` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer_care
-- ----------------------------
INSERT INTO `customer_care` VALUES ('1', '1', '纪念日', '送礼品', '2013-05-23 23:12:29', '节日纪念', '2013-05-28 23:12:34', '孙悟空', '1');
INSERT INTO `customer_care` VALUES ('2', '2', '生日', '上门拜访', '2013-05-23 23:14:00', '过生日', '2013-06-12 23:14:15', '猪八戒', '1');
INSERT INTO `customer_care` VALUES ('3', '2', 'fsd', '???', '2015-04-06 13:42:16', '', '2015-04-07 13:42:19', 'fdsa', '1');
INSERT INTO `customer_care` VALUES ('4', '2', 'adsf', '???', '2015-04-06 13:42:35', '', '2015-04-07 13:42:38', 'afa fsf ', '1');
INSERT INTO `customer_care` VALUES ('5', '2', 'asf', '???', '2015-04-06 13:42:46', 'afasdf', '2015-05-29 13:42:54', 'asfd', '1');

-- ----------------------------
-- Table structure for customer_condition
-- ----------------------------
DROP TABLE IF EXISTS `customer_condition`;
CREATE TABLE `customer_condition` (
  `condition_id` int(10) NOT NULL AUTO_INCREMENT,
  `condition_name` varchar(50) DEFAULT NULL,
  `condition_explain` varchar(1000) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`condition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer_condition
-- ----------------------------
INSERT INTO `customer_condition` VALUES ('1', '潜在客户', '可能成为客户的人', '1');
INSERT INTO `customer_condition` VALUES ('2', '意向客户', '有意愿车成为客户的人', '1');
INSERT INTO `customer_condition` VALUES ('3', '交易客户', '正在交易的客户', '1');

-- ----------------------------
-- Table structure for customer_info
-- ----------------------------
DROP TABLE IF EXISTS `customer_info`;
CREATE TABLE `customer_info` (
  `customer_id` int(10) NOT NULL AUTO_INCREMENT,
  `condition_id` int(10) DEFAULT NULL,
  `source_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `type_id` int(10) DEFAULT NULL,
  `customer_name` varchar(50) DEFAULT NULL,
  `customer_sex` varchar(10) DEFAULT NULL,
  `customer_mobile` varchar(20) DEFAULT NULL,
  `customer_qq` varchar(20) DEFAULT NULL,
  `customer_address` varchar(500) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_remark` varchar(1000) DEFAULT NULL,
  `customer_job` varchar(100) DEFAULT NULL,
  `customer_blog` varchar(100) DEFAULT NULL,
  `customer_tel` varbinary(20) DEFAULT NULL,
  `customer_msn` varchar(50) DEFAULT NULL,
  `birth_day` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customer_addtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customer_addman` varchar(50) DEFAULT NULL,
  `customer_changtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `change_man` varchar(20) DEFAULT NULL,
  `customer_company` varchar(50) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`customer_id`),
  KEY `FK_Reference_16` (`condition_id`),
  KEY `FK_Reference_17` (`source_id`),
  KEY `FK_Reference_18` (`type_id`),
  KEY `FK_Reference_23` (`user_id`),
  CONSTRAINT `FK_Reference_16` FOREIGN KEY (`condition_id`) REFERENCES `customer_condition` (`condition_id`),
  CONSTRAINT `FK_Reference_17` FOREIGN KEY (`source_id`) REFERENCES `customer_source` (`source_id`),
  CONSTRAINT `FK_Reference_18` FOREIGN KEY (`type_id`) REFERENCES `customer_type` (`type_id`),
  CONSTRAINT `FK_Reference_23` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer_info
-- ----------------------------
INSERT INTO `customer_info` VALUES ('1', '2', '1', '1', '2', '李四', '男', '13725425426', '2334343', '重庆', '379727687@qq.com', '									你好\r\n		\r\n		\r\n		\r\n		\r\n		', '老板', '3434322', 0x3534353435343333, '23234465', '2013-05-01 15:40:52', '2013-05-08 22:30:40', '张三', '2013-05-25 09:25:43', '张三', '思科', '1');
INSERT INTO `customer_info` VALUES ('2', '1', '1', '1', '1', '华纳', '女', '13924452345', '23456', '重庆三峡', '379727687@qq.com', '						反反复复\r\n		\r\n		', '学生', '6576', 0x3835383538353834, '45454555', '2013-05-01 15:40:53', '2013-05-23 23:05:44', '张三', '2013-05-25 09:31:47', '二位', '天天', '1');
INSERT INTO `customer_info` VALUES ('3', '1', '1', '1', '1', '刘欢', '男', '13854545454', '23245', '重庆', '379727687@qq.com', '			如同仁堂\r\n		', '学生', '6567', 0x3532343534373839, '53423134', '2013-05-21 15:40:54', '2013-05-23 23:08:52', '张三', '2013-05-25 09:32:48', '热热热', '微微', '1');
INSERT INTO `customer_info` VALUES ('4', '1', '1', '1', '1', '阿黄', '男', '13544455544', '454578', '重庆三峡学院', '379727687@qq.com', '			法国风格\r\n		', '学生', '6565', 0x3235343738353437, '45444455', '2013-05-01 15:40:54', '2013-05-23 23:10:17', '张三', '2013-05-25 09:33:24', '恒河', '三峡学院', '1');
INSERT INTO `customer_info` VALUES ('7', '1', '1', null, '3', '黄晓军', '男', '15111866066', '909239200', '重庆云阳', '909239200@qq.com', '这个客户很水', '屌丝', 'guanzhuwo@blog.com', 0x3432323332333233, '2323232', '1992-09-10 16:21:00', '2013-05-25 16:20:38', '蒋大爷', '2013-05-25 16:20:38', '', '敏军网络科技有限公司', '1');
INSERT INTO `customer_info` VALUES ('8', '3', '1', null, '1', '温庆心', '男', '13652354533', '', '爱上对方', '123156@qq.com', '						\r\n		\r\n		', '', '', '', '', '1991-11-03 16:50:38', '2013-05-25 16:49:28', 'admin', '2013-05-25 16:52:07', '', '', '1');
INSERT INTO `customer_info` VALUES ('9', '1', '1', '6', '2', '刘老师', '男', '15111866066', '', '重庆丰都', '379727687@qq.com', '			\r\n		这是个好老师', '程序猿', '', 0x3538313035373839, '', '1987-05-13 20:02:29', '2013-05-25 20:00:42', '蒋元征', '2013-05-25 20:04:57', '蒋元征', '中软国际', '1');

-- ----------------------------
-- Table structure for customer_linkman
-- ----------------------------
DROP TABLE IF EXISTS `customer_linkman`;
CREATE TABLE `customer_linkman` (
  `linkman_id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) DEFAULT NULL,
  `linkman_name` varchar(50) DEFAULT NULL,
  `linkman_sex` varchar(20) DEFAULT NULL,
  `linkman_job` varchar(100) DEFAULT NULL,
  `linkman_mobile` varchar(20) DEFAULT NULL,
  `linkman_age` int(10) DEFAULT NULL,
  `linkman_relation` varchar(50) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`linkman_id`),
  KEY `FK_Reference_20` (`customer_id`),
  CONSTRAINT `FK_Reference_20` FOREIGN KEY (`customer_id`) REFERENCES `customer_info` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer_linkman
-- ----------------------------
INSERT INTO `customer_linkman` VALUES ('1', '2', '合格', '男', '老板', '35667', '34', '上下属', '1');

-- ----------------------------
-- Table structure for customer_linkreord
-- ----------------------------
DROP TABLE IF EXISTS `customer_linkreord`;
CREATE TABLE `customer_linkreord` (
  `record_id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) DEFAULT NULL,
  `link_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `who_link` varchar(50) DEFAULT NULL,
  `link_type` varchar(50) DEFAULT NULL,
  `link_theme` varchar(200) DEFAULT NULL,
  `link_nexttime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_remark` varchar(1000) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`record_id`),
  KEY `FK_Reference_19` (`customer_id`),
  CONSTRAINT `FK_Reference_19` FOREIGN KEY (`customer_id`) REFERENCES `customer_info` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer_linkreord
-- ----------------------------
INSERT INTO `customer_linkreord` VALUES ('1', '1', '2013-05-23 23:15:11', '张三', '打电话', '过来买房', '2013-05-28 23:15:14', '很好', '1');

-- ----------------------------
-- Table structure for customer_source
-- ----------------------------
DROP TABLE IF EXISTS `customer_source`;
CREATE TABLE `customer_source` (
  `source_id` int(10) NOT NULL AUTO_INCREMENT,
  `source_name` varchar(50) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer_source
-- ----------------------------
INSERT INTO `customer_source` VALUES ('1', '自己上门', '1');
INSERT INTO `customer_source` VALUES ('2', '朋友推荐', '1');
INSERT INTO `customer_source` VALUES ('3', '百度网', '1');

-- ----------------------------
-- Table structure for customer_type
-- ----------------------------
DROP TABLE IF EXISTS `customer_type`;
CREATE TABLE `customer_type` (
  `type_id` int(10) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer_type
-- ----------------------------
INSERT INTO `customer_type` VALUES ('1', '客户', '1');
INSERT INTO `customer_type` VALUES ('2', '合作伙伴', '1');
INSERT INTO `customer_type` VALUES ('3', '供应商', '1');
INSERT INTO `customer_type` VALUES ('4', '合作伙伴', '1');

-- ----------------------------
-- Table structure for department_info
-- ----------------------------
DROP TABLE IF EXISTS `department_info`;
CREATE TABLE `department_info` (
  `department_id` int(10) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(50) DEFAULT NULL,
  `department_desc` varchar(500) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of department_info
-- ----------------------------
INSERT INTO `department_info` VALUES ('1', '财务部', '很有钱', '1');
INSERT INTO `department_info` VALUES ('3', '销售部', '搞销售的', '1');

-- ----------------------------
-- Table structure for email_info
-- ----------------------------
DROP TABLE IF EXISTS `email_info`;
CREATE TABLE `email_info` (
  `email_id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `email_content` varchar(2000) DEFAULT NULL,
  `email_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `email_state` varchar(50) DEFAULT NULL,
  `email_theme` varchar(200) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`email_id`),
  KEY `FK_Reference_14` (`user_id`),
  KEY `FK_Reference_21` (`customer_id`),
  CONSTRAINT `FK_Reference_14` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`),
  CONSTRAINT `FK_Reference_21` FOREIGN KEY (`customer_id`) REFERENCES `customer_info` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of email_info
-- ----------------------------
INSERT INTO `email_info` VALUES ('21', '4', '1', '第三代是的大多数都是', '2013-05-25 19:48:27', '1', '地地道道是', '1');
INSERT INTO `email_info` VALUES ('22', '4', '4', '反对反对', '2013-05-25 19:49:15', '0', '风格大方的', '0');
INSERT INTO `email_info` VALUES ('23', '4', '4', '反对反对', '2013-05-25 19:49:28', '1', '风格大方的', '1');
INSERT INTO `email_info` VALUES ('24', '2', '1', '刚刚', '2013-05-25 19:50:38', '1', '123', '1');
INSERT INTO `email_info` VALUES ('25', '9', '1', '祝你生日快乐！身体健康！', '2013-05-25 20:22:31', '0', '生日快乐', '1');

-- ----------------------------
-- Table structure for house_info
-- ----------------------------
DROP TABLE IF EXISTS `house_info`;
CREATE TABLE `house_info` (
  `house_id` int(10) NOT NULL AUTO_INCREMENT,
  `type_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `house_address` varchar(500) DEFAULT NULL,
  `house_price` int(20) DEFAULT NULL,
  `house_ambient` varchar(1000) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`house_id`),
  KEY `FK_Reference_13` (`user_id`),
  KEY `FK_Reference_26` (`type_id`),
  CONSTRAINT `FK_Reference_13` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`),
  CONSTRAINT `FK_Reference_26` FOREIGN KEY (`type_id`) REFERENCES `house_type` (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of house_info
-- ----------------------------
INSERT INTO `house_info` VALUES ('6', '2', '3', '滨江路', '10000', '很好啦！都来看看啊！', '1');
INSERT INTO `house_info` VALUES ('7', '1', '1', '三峡学院', '500', '你猜！', '1');
INSERT INTO `house_info` VALUES ('8', '1', '4', '2000', '500', 'gh ', '1');
INSERT INTO `house_info` VALUES ('9', '1', '1', '重庆云烟', '111', '这里是结婚生子的好地方', '1');
INSERT INTO `house_info` VALUES ('10', '1', '6', '重庆万州', '1200', '案发大发第三方', '1');
INSERT INTO `house_info` VALUES ('11', '1', '1', '重庆万州', '234', '', '1');
INSERT INTO `house_info` VALUES ('12', '1', '6', '重庆万州', '1200', '5555', '1');
INSERT INTO `house_info` VALUES ('13', '1', '1', 'dsf', '100', 'gh', '1');
INSERT INTO `house_info` VALUES ('14', '1', '1', 'guyo', '10', 'oll[\'hi', '1');
INSERT INTO `house_info` VALUES ('15', '1', '1', '41', '10', 'fdijdty', '1');
INSERT INTO `house_info` VALUES ('16', '1', '1', '10', '1001', '10', '1');
INSERT INTO `house_info` VALUES ('17', '1', '1', '1010', '101010', '10101010', '1');
INSERT INTO `house_info` VALUES ('18', '1', '1', '1010', '1010', '10101010', '1');
INSERT INTO `house_info` VALUES ('19', '1', '1', '1010', '10101', '01101010', '1');
INSERT INTO `house_info` VALUES ('20', '1', '1', '1010', '10101', '0101010', '1');
INSERT INTO `house_info` VALUES ('21', '1', '1', '100', '1010', '010100', '1');
INSERT INTO `house_info` VALUES ('22', '1', '1', '1010', '1010', '101010', '1');
INSERT INTO `house_info` VALUES ('23', '1', '1', '1010', '101010', '10101010', '1');
INSERT INTO `house_info` VALUES ('24', '1', '1', '10100', '1010', '101000', '1');
INSERT INTO `house_info` VALUES ('25', '1', '1', '10100101', '101010', '101010', '1');
INSERT INTO `house_info` VALUES ('26', '1', '1', '1010', '101010', '1010100', '1');
INSERT INTO `house_info` VALUES ('27', '1', '1', '1010', '101010', '10101010', '1');
INSERT INTO `house_info` VALUES ('28', '1', '1', '10101', '10101', '1001010', '1');
INSERT INTO `house_info` VALUES ('29', '1', '1', '101011010', '1010', '0101010100', '1');
INSERT INTO `house_info` VALUES ('30', '1', '1', '1010', '1010', '101010', '1');
INSERT INTO `house_info` VALUES ('31', '1', '1', '010010', '10101010', '101010', '1');
INSERT INTO `house_info` VALUES ('32', '1', '1', '1010010100', '101010', '10101010', '1');
INSERT INTO `house_info` VALUES ('33', '1', '1', '10010', '1010101', '101010', '1');
INSERT INTO `house_info` VALUES ('34', '1', '1', '12.43', '453254', '45254', '1');
INSERT INTO `house_info` VALUES ('35', '1', '1', '452542', '54254', '254245245', '1');
INSERT INTO `house_info` VALUES ('36', '1', '1', '4524', '542542', '54254245', '1');
INSERT INTO `house_info` VALUES ('37', '1', '1', '54245', '45254', '45242452', '1');
INSERT INTO `house_info` VALUES ('38', '1', '1', '4524', '452', '45254', '1');
INSERT INTO `house_info` VALUES ('39', '1', '1', 'sdf', '1000', 'dsgf', '1');
INSERT INTO `house_info` VALUES ('40', '1', '1', 'dgf', '10', 'gfh', '1');
INSERT INTO `house_info` VALUES ('41', '1', '1', 'dgf', '10', 'gfh', '1');
INSERT INTO `house_info` VALUES ('42', '1', '1', '?????', '20', '??????', '1');
INSERT INTO `house_info` VALUES ('43', '1', '1', '???', '10', '?????', '1');
INSERT INTO `house_info` VALUES ('44', '1', '1', 'dgf', '10', 'gfh', '1');
INSERT INTO `house_info` VALUES ('45', '1', '1', 'dgf', '10', 'gfh', '1');
INSERT INTO `house_info` VALUES ('46', '1', '1', 'dgf', '10', 'gfh', '1');
INSERT INTO `house_info` VALUES ('47', '1', '1', 'dfsdf', '20', '??????', '1');
INSERT INTO `house_info` VALUES ('48', '1', '1', '???', '20', '???????', '1');
INSERT INTO `house_info` VALUES ('49', '1', '1', '?????', '200', '?????', '1');
INSERT INTO `house_info` VALUES ('50', '1', '1', '???', '10', '????', '1');
INSERT INTO `house_info` VALUES ('51', '1', '1', '???', '10', '????', '1');
INSERT INTO `house_info` VALUES ('52', '1', '1', '4524', '542452', '57254', '1');
INSERT INTO `house_info` VALUES ('53', '1', '1', 'dffdf', '20', '???', '1');
INSERT INTO `house_info` VALUES ('54', '1', '1', '???? ', '236', '?????', '1');
INSERT INTO `house_info` VALUES ('55', '1', '1', '???? ', '236', '?????', '1');
INSERT INTO `house_info` VALUES ('56', '1', '1', '???', '1232', '????', '1');
INSERT INTO `house_info` VALUES ('57', '1', '1', '???', '1232', '????', '1');
INSERT INTO `house_info` VALUES ('58', '1', '1', '???', '1232', '????', '1');
INSERT INTO `house_info` VALUES ('59', '1', '1', '???', '1232', '????', '1');
INSERT INTO `house_info` VALUES ('60', '1', '1', '???', '1232', '????', '1');
INSERT INTO `house_info` VALUES ('61', '1', '1', '???', '1232', '????', '1');
INSERT INTO `house_info` VALUES ('62', '1', '1', '??', '10', '???', '1');
INSERT INTO `house_info` VALUES ('63', '1', '1', '??', '10', '???', '1');
INSERT INTO `house_info` VALUES ('64', '1', '1', '??? ', '26', '??????', '1');
INSERT INTO `house_info` VALUES ('65', '1', '1', '??? ', '26', '??????', '1');
INSERT INTO `house_info` VALUES ('66', '1', '1', '65???', '2561', '??? ', '1');
INSERT INTO `house_info` VALUES ('67', '1', '1', '??', '12356', '??', '1');
INSERT INTO `house_info` VALUES ('68', '1', '1', '??', '12356', '?????', '1');
INSERT INTO `house_info` VALUES ('69', '1', '1', '??f', '10', '????', '1');
INSERT INTO `house_info` VALUES ('70', '1', '1', '??f', '10', '????', '1');
INSERT INTO `house_info` VALUES ('71', '1', '1', '? ', '123', '?????', '1');

-- ----------------------------
-- Table structure for house_type
-- ----------------------------
DROP TABLE IF EXISTS `house_type`;
CREATE TABLE `house_type` (
  `type_id` int(10) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of house_type
-- ----------------------------
INSERT INTO `house_type` VALUES ('1', '三室一厅', '1');
INSERT INTO `house_type` VALUES ('2', '三室两厅', '1');
INSERT INTO `house_type` VALUES ('3', '两室一厅', '1');
INSERT INTO `house_type` VALUES ('4', '四室两厅', '1');

-- ----------------------------
-- Table structure for notice_info
-- ----------------------------
DROP TABLE IF EXISTS `notice_info`;
CREATE TABLE `notice_info` (
  `notice_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `notice_item` varchar(100) DEFAULT NULL,
  `notice_content` varchar(2000) DEFAULT NULL,
  `notice_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `notice_endtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`notice_id`),
  KEY `FK_Reference_12` (`user_id`),
  CONSTRAINT `FK_Reference_12` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice_info
-- ----------------------------
INSERT INTO `notice_info` VALUES ('3', '4', '最近要开会', '记得带钱', '2013-05-23 23:22:12', '2013-05-30 23:22:29', '1');

-- ----------------------------
-- Table structure for rfcorp_verified_info
-- ----------------------------
DROP TABLE IF EXISTS `rfcorp_verified_info`;
CREATE TABLE `rfcorp_verified_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `id_card` varchar(50) DEFAULT NULL,
  `realname` varchar(10) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile_telephone` varchar(20) DEFAULT NULL,
  `check_time` int(11) DEFAULT NULL,
  `all_verify` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of rfcorp_verified_info
-- ----------------------------
INSERT INTO `rfcorp_verified_info` VALUES ('37', '41479', '330722196501292110', '阿杰克', null, '13888888888', '1416540531', null);
INSERT INTO `rfcorp_verified_info` VALUES ('38', '87803', '51072319870313665X ', '张三那', 'admin888@qq.com', '13666666666', '1416542016', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('39', '87802', null, null, '108888453@qq.com', '13604942420', '1416542303', '0');
INSERT INTO `rfcorp_verified_info` VALUES ('40', '87801', '510723197101221473 ', '张三', '4654251321@163.com', '13604942425', '1416551817', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('41', '87800', '370205197405213513 ', '张三', '103148853@qq.com', null, '1416551975', null);
INSERT INTO `rfcorp_verified_info` VALUES ('42', '87799', '430581198308229410', '张三', '103145453@qq.com', '15888888888', '1416553108', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('43', '87797', '430581198308226236', '张三', '234134@qq.com', '13604945555', '1416553407', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('44', '87796', '430581198308228370', '张三', 'sadsa@123.com', '13555555586', '1416553936', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('45', '87795', '620101198001252036', '张三', 'saber@spade9.com', '13665654574', '1416554167', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('46', '87794', '330722195611125933', '张三', '21564564354234@163.com', '13666565454', '1416643527', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('47', '87793', null, null, null, '13555454524', '1416554685', null);
INSERT INTO `rfcorp_verified_info` VALUES ('48', '87792', null, null, null, '13555585454', '1416554778', '0');
INSERT INTO `rfcorp_verified_info` VALUES ('49', '87791', '370304198411066373', '网哈哈', '84658815@qq.com', '13456545845', '1416555008', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('50', '87786', '510811198403014191', '张三', '122433@qq.com', '13555926655', '1416562850', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('51', '87781', '330724198107250731', '张三', '86999986011@qq.com', null, '1416622181', null);
INSERT INTO `rfcorp_verified_info` VALUES ('52', '87780', '330183198101251116', '张三', '869860@qq.com', '13604942423', '1416623377', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('53', '87775', '330724196201110015', '张三', 'whitebear168@ymail.com', '13555955854', '1416624676', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('54', '87771', '330721198105285413', '望见徐', '12qwe3@qq.com', '13555656565', '1416624931', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('58', '87770', '330724194910022916', '爱谁谁', null, null, '1416625599', null);
INSERT INTO `rfcorp_verified_info` VALUES ('59', '87769', '330725196411150089', '何晨光', null, '13888545845', '1416626894', null);
INSERT INTO `rfcorp_verified_info` VALUES ('60', '87767', '340901197511280215', '陆氏林', '2860728392@qq.com', '13555555845', '1416627178', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('61', '87755', '330722195105090424', '谢钊丰', 'liwnagt@126.com', '13554584575', '1416628055', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('62', '87753', '330702196310070827', '方少龙', 'dou888888e@163.com', '13504327826', '1416629330', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('63', '87751', '330723196906151718', '叶正金', 'zhengjing0517@126.com', '13888545484', '1416631599', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('64', '87749', '330723194910260053', '黄巧珍', null, '13888545545', '1416633263', null);
INSERT INTO `rfcorp_verified_info` VALUES ('65', '87747', '330724197606156219', '吴莹炜', 'nihdu888@126.com', '13554644545', '1416633421', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('66', '87741', '330702197410120494', '李梦超', 'quirn00@126.com', '13889575545', '1416635191', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('67', '87739', null, null, 'stduencz@163.com', null, '1416636144', null);
INSERT INTO `rfcorp_verified_info` VALUES ('68', '87735', '33022119670222791X', '宋冬园', '478915238@qq.com', '13665656545', '1416640672', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('69', '87733', '330722197407144511', '吴代春', '85294619@qq.com', '13555655654', '1416641468', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('70', '87709', '330723196212231174', '邓耀威', 'bimuyu8888@163.com', '13654454545', '1416645224', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('80', '87685', '330722197510228617', '陈洁娜', '1626258323@qq.com', '13555565645', '1416823379', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('81', '86963', '330726195603074713', '白伟', 'baiweibw@126.com', '13555655487', '1416824016', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('82', '87701', '330722196912192317', '陆敏顺', 'yaodobeijuc@yeah.net', '13555655454', '1416825771', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('83', '87699', '330724196304050748', '张文竣', '951105148@qq.com', '13333656545', '1416826352', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('84', '87773', '330722196905111216', '你妹啊', '', '13604944242', '1416827064', null);
INSERT INTO `rfcorp_verified_info` VALUES ('85', '86913', null, null, '465771601@qq.com', null, '1418016793', null);
INSERT INTO `rfcorp_verified_info` VALUES ('86', '86915', null, null, '869999860', null, '1418018753', null);
INSERT INTO `rfcorp_verified_info` VALUES ('87', '86917', null, null, '869@qq.com', null, '1418021645', null);
INSERT INTO `rfcorp_verified_info` VALUES ('88', '86919', null, null, '123', null, '1418023543', null);
INSERT INTO `rfcorp_verified_info` VALUES ('89', '86921', null, null, '86999520@qq.com', null, '1418024236', null);
INSERT INTO `rfcorp_verified_info` VALUES ('90', '86923', '522635198308283119', '廖镇山', '', '13600522264', '1418026445', null);
INSERT INTO `rfcorp_verified_info` VALUES ('104', '33363', '330702197108020812', '张三丰', '651924195@qq.com', '13604942488', '1418271978', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('105', '85821', '210421198403162020', '何金狮', 'duninmuj@163.com', '13555999564', '1418360386', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('106', '85795', '330724197501066217', '你大爷', '2642527236@qq.com', '13555545444', '1418450498', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('107', '85793', '43022419760703747X', '呵呵', '1304089852@qq.com', '13600055565', '1418453308', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('108', '85807', ' 610302197709058125', '张大嘴', '2077331638@qq.com', '13555665644', '1418695436', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('109', '85809', '510124197910081486', '杨其峰', '2998564434@qq.com', '13555666554', '1418696654', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('110', '85813', '532628198704244638', '黄俊', '1363527734@qq.com', '13555644454', '1418711343', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('111', '85803', '120000198603236594', '张雄', '2786060420@qq.com', '13555655484', '1418712079', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('112', '85801', ' 51170219870626850X', '张志军', '2752797843@qq.com', '13555665524', '1418712353', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('113', '85799', '511702198807288390', '黄振辉', '1302659155@qq.com', '13666566545', '1418712574', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('114', '85797', '511702197008231350', '王转丽', '1808295520@qq.com', '13555655458', '1418714257', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('115', '85817', '522635197801141558', '石增', '1752516110@qq.com', '13665545845', '1418715639', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('116', '85815', '532628197106263359', '连少飞', '1120364230@qq.com', '13565685645', '1418718156', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('118', '85811', '532628197706141814', '王明奕', '6180986@qq.com', '13604942555', '1418720784', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('119', '85805', '532628198006157350', '张靖', '2021535578@qq.com', '13555655488', '1418723890', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('120', '85779', ' 532628198905224879', '胡建林', '405645384@qq.com', '14755655454', '1418728916', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('121', '85743', '411525198407154262', '任才', 'renjian33@126.com', '13555656545', '1418790578', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('122', '85747', '411525197206189026', '呵呵', '105558798@qq.com', '13555655545', '1418791612', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('123', '85745', '411525198902231341', '阿登省', 'timo@gmail.com', '13666565548', '1418791762', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('124', '85845', '330726197810281714', '杨燕清', 'yanqinglaoda123@163.com', '13555655225', '1418887984', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('125', '85829', '330726198106171719', '张宁', '23022783461@qq.com', '13555565554', '1419215508', null);
INSERT INTO `rfcorp_verified_info` VALUES ('126', '85825', '330722198307080324', '杜俊锴', '478241708@qq.com', '13666566554', '1419216243', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('127', '60417', null, null, null, '13605455545', '1419578157', null);
INSERT INTO `rfcorp_verified_info` VALUES ('128', '60162', '21028119930111', '宋建', '869999813260@qq.com', '13604942422', '1419578500', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('129', '87805', '330702197601286024', '你大爷', '123456sdf@qq.com', '13555456455', '1419675862', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('130', '85785', '330725196303092117', '施嘉恒', '277706508@qq.com', '13555455487', '1419676729', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('131', '85835', '21012438531111', '陈小英', '1229768594@qq.com', '13555455544', '1419929708', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('132', '85865', null, null, null, '', '1419933895', null);
INSERT INTO `rfcorp_verified_info` VALUES ('133', '60355', '88888888880202', '谭朝杰', 'iij33321@163.com', '13655522242', '1420168540', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('134', '60420', '21022222210122', '王建明', '75414432@qq.COM', '13666555245', '1420176360', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('135', '60419', '21028551121212', '陈良', '605956222@qq.com', '13513112212', '1420176705', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('136', '60159', null, null, '', null, '1420189429', null);
INSERT INTO `rfcorp_verified_info` VALUES ('137', '60103', '21028116650102', '王枫', null, null, '1420254247', null);
INSERT INTO `rfcorp_verified_info` VALUES ('144', '43366', '21028119960203', '高振强', '827028140@qq.com', '13555999548', '1422514750', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('145', '43367', '21028119550203', '刘云鹏', '53649092@qq.com', '13558454231', '1422515295', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('146', '33370', '21028119950502', '郭俊州', 'gjz0931@yahoo.com.cn', '', '1422515546', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('147', '85843', '21028119950501', '孙国军', '2481268332@qq.com', '13555456454', '1422613883', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('148', '85823', '21028119660501', '段文臣', 'dwcckloo@yeah.net', '13555645545', '1422674957', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('149', '85761', '21028119650203', '赵晓兴', '40884854@qq.com', '13555464542', '1422675154', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('150', '87808', '21028119930111', '张三丰', null, '13604942422', '1422853603', null);
INSERT INTO `rfcorp_verified_info` VALUES ('151', '60105', '21028119930111', '约翰', 'jitming8@yahoo.com', null, '1422857959', null);
INSERT INTO `rfcorp_verified_info` VALUES ('152', '44375', null, null, 'mar_kou_yan_g@63.com', null, '1422858052', null);
INSERT INTO `rfcorp_verified_info` VALUES ('153', '43364', null, null, '2630757579@qq.com', null, '1422927779', null);
INSERT INTO `rfcorp_verified_info` VALUES ('154', '44374', '21028119910201', '陈飞', '77864768@qq.com', '13555646854', '1422932167', '1');
INSERT INTO `rfcorp_verified_info` VALUES ('156', '87812', '21028119660210', '吴荣', '1930809324@qq.com', null, '1423826909', null);
INSERT INTO `rfcorp_verified_info` VALUES ('157', '87783', '21028119900201', '张三', null, '13605151212', '1423827186', null);
INSERT INTO `rfcorp_verified_info` VALUES ('158', '33379', null, null, 'duzhewei.dd@qq.com', null, '1428406330', null);

-- ----------------------------
-- Table structure for user_info
-- ----------------------------
DROP TABLE IF EXISTS `user_info`;
CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `department_id` int(10) DEFAULT NULL,
  `role_id` int(10) DEFAULT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `user_sex` varchar(10) DEFAULT NULL,
  `user_mobile` varchar(20) DEFAULT NULL,
  `user_age` int(10) DEFAULT NULL,
  `user_address` varchar(500) DEFAULT NULL,
  `user_num` varchar(100) DEFAULT NULL,
  `user_pw` varchar(50) DEFAULT NULL,
  `user_tel` varchar(20) DEFAULT NULL,
  `user_idnum` varchar(20) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `user_addtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_addman` varchar(50) DEFAULT NULL,
  `user_changetime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_changeman` varchar(50) DEFAULT NULL,
  `user_intest` varchar(1000) DEFAULT NULL,
  `user_diploma` varchar(20) DEFAULT NULL,
  `user_bankcard` varchar(20) DEFAULT NULL,
  `user_nation` varchar(20) DEFAULT NULL,
  `is_married` varchar(10) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`user_id`),
  KEY `FK_Reference_22` (`department_id`),
  KEY `FK_Reference_24` (`role_id`),
  CONSTRAINT `FK_Reference_22` FOREIGN KEY (`department_id`) REFERENCES `department_info` (`department_id`),
  CONSTRAINT `FK_Reference_24` FOREIGN KEY (`role_id`) REFERENCES `user_role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_info
-- ----------------------------
INSERT INTO `user_info` VALUES ('1', '1', '1', '张三', '男', '13525452584', '20', '万州', 'admin', '123456', '52000112', '500234154545745474', '3797687@qq.com', '2013-05-25 09:37:18', '肉骨粉', '2013-05-25 16:43:05', '未修改', '很多', '本科', '5442232327863358787', '汉', '已婚', '1');
INSERT INTO `user_info` VALUES ('3', '1', '2', '王五', '男', '13254545454', '22', '重庆三峡学院', '123', '123', '22323244', '522141444514744547', '87592@qq.com', '2013-05-25 09:37:07', '张三', '2013-05-25 09:29:05', '未修改', '斗地主', '本科', '2323232345555555522', '汉', '未婚', '1');
INSERT INTO `user_info` VALUES ('4', '1', '2', '孙悟空', '男', '13545454545', '55', '花果山', '456', '456', '54584785', '524147444584574554', '39547@qq.com', '2013-05-25 09:37:04', '张三', '2013-05-25 09:30:14', '未修改', '吃桃子', '初中', '3535355488676754578', '汉', '离异', '1');
INSERT INTO `user_info` VALUES ('5', '1', '2', '猪八戒', '男', '13544477747', '2', '高老庄', '789', '789', '52000112', '524154655895854744', '3963547@qq.com', '2013-05-25 09:36:59', '张三', '2013-05-25 09:29:33', '未修改', '吃西瓜', '初中', '3535355555454787887', '汉', '已婚', '1');
INSERT INTO `user_info` VALUES ('6', '3', '1', '蒋元征', '男', '15923219017', '20', '重庆双桥', 'jiang', 'jiang1314', '58105789', '500111199205191111', '253507692@qq.com', '2013-05-25 16:18:31', 'admin', '2013-05-25 16:20:27', '未修改', '上网、玩游戏', '本科', '6222023100045180177', '汉族', '未婚', '1');
INSERT INTO `user_info` VALUES ('7', '3', '1', '黄建新', '男', '15923219011', '21', '重庆开县', 'huang', '123456', '58105744', '500111199205191114', '253507692@qq.com', '2013-05-25 19:55:29', '蒋元征', '2013-05-25 19:58:04', '未修改', '上网、DNF', '初中', '6222023100045180111', '汉族', '已婚', '1');

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `role_id` int(10) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) DEFAULT NULL,
  `role_power` int(10) DEFAULT NULL,
  `is_used` varchar(10) DEFAULT '1',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES ('1', '管理员', '3', '1');
INSERT INTO `user_role` VALUES ('2', '员工', '2', '1');
INSERT INTO `user_role` VALUES ('3', '老板', '1', '1');

-- ----------------------------
-- Table structure for verified
-- ----------------------------
DROP TABLE IF EXISTS `verified`;
CREATE TABLE `verified` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `id_card` varchar(50) DEFAULT NULL,
  `realname` varchar(10) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile_telephone` varchar(20) DEFAULT NULL,
  `check_time` int(11) DEFAULT NULL,
  `all_verify` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of verified
-- ----------------------------
INSERT INTO `verified` VALUES ('37', '41479', '330722196501292110', '阿杰克', null, '13888888888', '1416540531', null);
INSERT INTO `verified` VALUES ('38', '87803', '51072319870313665X ', '张三那', 'admin888@qq.com', '13666666666', '1416542016', '1');
INSERT INTO `verified` VALUES ('39', '87802', null, null, '108888453@qq.com', '13604942420', '1416542303', '0');
INSERT INTO `verified` VALUES ('40', '87801', '510723197101221473 ', '张三', '4654251321@163.com', '13604942425', '1416551817', '1');
INSERT INTO `verified` VALUES ('41', '87800', '370205197405213513 ', '张三', '103148853@qq.com', null, '1416551975', null);
INSERT INTO `verified` VALUES ('42', '87799', '430581198308229410', '张三', '103145453@qq.com', '15888888888', '1416553108', '1');
INSERT INTO `verified` VALUES ('43', '87797', '430581198308226236', '张三', '234134@qq.com', '13604945555', '1416553407', '1');
INSERT INTO `verified` VALUES ('44', '87796', '430581198308228370', '张三', 'sadsa@123.com', '13555555586', '1416553936', '1');
INSERT INTO `verified` VALUES ('45', '87795', '620101198001252036', '张三', 'saber@spade9.com', '13665654574', '1416554167', '1');
INSERT INTO `verified` VALUES ('46', '87794', '330722195611125933', '张三', '21564564354234@163.com', '13666565454', '1416643527', '1');
INSERT INTO `verified` VALUES ('47', '87793', null, null, null, '13555454524', '1416554685', null);
INSERT INTO `verified` VALUES ('48', '87792', null, null, null, '13555585454', '1416554778', '0');
INSERT INTO `verified` VALUES ('49', '87791', '370304198411066373', '网哈哈', '84658815@qq.com', '13456545845', '1416555008', '1');
INSERT INTO `verified` VALUES ('50', '87786', '510811198403014191', '张三', '122433@qq.com', '13555926655', '1416562850', '1');
INSERT INTO `verified` VALUES ('51', '87781', '330724198107250731', '张三', '86999986011@qq.com', null, '1416622181', null);
INSERT INTO `verified` VALUES ('52', '87780', '330183198101251116', '张三', '869860@qq.com', '13604942423', '1416623377', '1');
INSERT INTO `verified` VALUES ('53', '87775', '330724196201110015', '张三', 'whitebear168@ymail.com', '13555955854', '1416624676', '1');
INSERT INTO `verified` VALUES ('54', '87771', '330721198105285413', '望见徐', '12qwe3@qq.com', '13555656565', '1416624931', '1');
INSERT INTO `verified` VALUES ('58', '87770', '330724194910022916', '爱谁谁', null, null, '1416625599', null);
INSERT INTO `verified` VALUES ('59', '87769', '330725196411150089', '何晨光', null, '13888545845', '1416626894', null);
INSERT INTO `verified` VALUES ('60', '87767', '340901197511280215', '陆氏林', '2860728392@qq.com', '13555555845', '1416627178', '1');
INSERT INTO `verified` VALUES ('61', '87755', '330722195105090424', '谢钊丰', 'liwnagt@126.com', '13554584575', '1416628055', '1');
INSERT INTO `verified` VALUES ('62', '87753', '330702196310070827', '方少龙', 'dou888888e@163.com', '13504327826', '1416629330', '1');
INSERT INTO `verified` VALUES ('63', '87751', '330723196906151718', '叶正金', 'zhengjing0517@126.com', '13888545484', '1416631599', '1');
INSERT INTO `verified` VALUES ('64', '87749', '330723194910260053', '黄巧珍', null, '13888545545', '1416633263', null);
INSERT INTO `verified` VALUES ('65', '87747', '330724197606156219', '吴莹炜', 'nihdu888@126.com', '13554644545', '1416633421', '1');
INSERT INTO `verified` VALUES ('66', '87741', '330702197410120494', '李梦超', 'quirn00@126.com', '13889575545', '1416635191', '1');
INSERT INTO `verified` VALUES ('67', '87739', null, null, 'stduencz@163.com', null, '1416636144', null);
INSERT INTO `verified` VALUES ('68', '87735', '33022119670222791X', '宋冬园', '478915238@qq.com', '13665656545', '1416640672', '1');
INSERT INTO `verified` VALUES ('69', '87733', '330722197407144511', '吴代春', '85294619@qq.com', '13555655654', '1416641468', '1');
INSERT INTO `verified` VALUES ('70', '87709', '330723196212231174', '邓耀威', 'bimuyu8888@163.com', '13654454545', '1416645224', '1');
INSERT INTO `verified` VALUES ('80', '87685', '330722197510228617', '陈洁娜', '1626258323@qq.com', '13555565645', '1416823379', '1');
INSERT INTO `verified` VALUES ('81', '86963', '330726195603074713', '白伟', 'baiweibw@126.com', '13555655487', '1416824016', '1');
INSERT INTO `verified` VALUES ('82', '87701', '330722196912192317', '陆敏顺', 'yaodobeijuc@yeah.net', '13555655454', '1416825771', '1');
INSERT INTO `verified` VALUES ('83', '87699', '330724196304050748', '张文竣', '951105148@qq.com', '13333656545', '1416826352', '1');
INSERT INTO `verified` VALUES ('84', '87773', '330722196905111216', '你妹啊', '', '13604944242', '1416827064', null);
INSERT INTO `verified` VALUES ('85', '86913', null, null, '465771601@qq.com', null, '1418016793', null);
INSERT INTO `verified` VALUES ('86', '86915', null, null, '869999860', null, '1418018753', null);
INSERT INTO `verified` VALUES ('87', '86917', null, null, '869@qq.com', null, '1418021645', null);
INSERT INTO `verified` VALUES ('88', '86919', null, null, '123', null, '1418023543', null);
INSERT INTO `verified` VALUES ('89', '86921', null, null, '86999520@qq.com', null, '1418024236', null);
INSERT INTO `verified` VALUES ('90', '86923', '522635198308283119', '廖镇山', '', '13600522264', '1418026445', null);
INSERT INTO `verified` VALUES ('104', '33363', '330702197108020812', '张三丰', '651924195@qq.com', '13604942488', '1418271978', '1');
INSERT INTO `verified` VALUES ('105', '85821', '210421198403162020', '何金狮', 'duninmuj@163.com', '13555999564', '1418360386', '1');
INSERT INTO `verified` VALUES ('106', '85795', '330724197501066217', '你大爷', '2642527236@qq.com', '13555545444', '1418450498', '1');
INSERT INTO `verified` VALUES ('107', '85793', '43022419760703747X', '呵呵', '1304089852@qq.com', '13600055565', '1418453308', '1');
INSERT INTO `verified` VALUES ('108', '85807', ' 610302197709058125', '张大嘴', '2077331638@qq.com', '13555665644', '1418695436', '1');
INSERT INTO `verified` VALUES ('109', '85809', '510124197910081486', '杨其峰', '2998564434@qq.com', '13555666554', '1418696654', '1');
INSERT INTO `verified` VALUES ('110', '85813', '532628198704244638', '黄俊', '1363527734@qq.com', '13555644454', '1418711343', '1');
INSERT INTO `verified` VALUES ('111', '85803', '120000198603236594', '张雄', '2786060420@qq.com', '13555655484', '1418712079', '1');
INSERT INTO `verified` VALUES ('112', '85801', ' 51170219870626850X', '张志军', '2752797843@qq.com', '13555665524', '1418712353', '1');
INSERT INTO `verified` VALUES ('113', '85799', '511702198807288390', '黄振辉', '1302659155@qq.com', '13666566545', '1418712574', '1');
INSERT INTO `verified` VALUES ('114', '85797', '511702197008231350', '王转丽', '1808295520@qq.com', '13555655458', '1418714257', '1');
INSERT INTO `verified` VALUES ('115', '85817', '522635197801141558', '石增', '1752516110@qq.com', '13665545845', '1418715639', '1');
INSERT INTO `verified` VALUES ('116', '85815', '532628197106263359', '连少飞', '1120364230@qq.com', '13565685645', '1418718156', '1');
INSERT INTO `verified` VALUES ('118', '85811', '532628197706141814', '王明奕', '6180986@qq.com', '13604942555', '1418720784', '1');
INSERT INTO `verified` VALUES ('119', '85805', '532628198006157350', '张靖', '2021535578@qq.com', '13555655488', '1418723890', '1');
INSERT INTO `verified` VALUES ('120', '85779', ' 532628198905224879', '胡建林', '405645384@qq.com', '14755655454', '1418728916', '1');
INSERT INTO `verified` VALUES ('121', '85743', '411525198407154262', '任才', 'renjian33@126.com', '13555656545', '1418790578', '1');
INSERT INTO `verified` VALUES ('122', '85747', '411525197206189026', '呵呵', '105558798@qq.com', '13555655545', '1418791612', '1');
INSERT INTO `verified` VALUES ('123', '85745', '411525198902231341', '阿登省', 'timo@gmail.com', '13666565548', '1418791762', '1');
INSERT INTO `verified` VALUES ('124', '85845', '330726197810281714', '杨燕清', 'yanqinglaoda123@163.com', '13555655225', '1418887984', '1');
INSERT INTO `verified` VALUES ('125', '85829', '330726198106171719', '张宁', '23022783461@qq.com', '13555565554', '1419215508', null);
INSERT INTO `verified` VALUES ('126', '85825', '330722198307080324', '杜俊锴', '478241708@qq.com', '13666566554', '1419216243', '1');
INSERT INTO `verified` VALUES ('127', '60417', null, null, null, '13605455545', '1419578157', null);
INSERT INTO `verified` VALUES ('128', '60162', '21028119930111', '宋建', '869999813260@qq.com', '13604942422', '1419578500', '1');
INSERT INTO `verified` VALUES ('129', '87805', '330702197601286024', '你大爷', '123456sdf@qq.com', '13555456455', '1419675862', '1');
INSERT INTO `verified` VALUES ('130', '85785', '330725196303092117', '施嘉恒', '277706508@qq.com', '13555455487', '1419676729', '1');
INSERT INTO `verified` VALUES ('131', '85835', '21012438531111', '陈小英', '1229768594@qq.com', '13555455544', '1419929708', '1');
INSERT INTO `verified` VALUES ('132', '85865', null, null, null, '', '1419933895', null);
INSERT INTO `verified` VALUES ('133', '60355', '88888888880202', '谭朝杰', 'iij33321@163.com', '13655522242', '1420168540', '1');
INSERT INTO `verified` VALUES ('134', '60420', '21022222210122', '王建明', '75414432@qq.COM', '13666555245', '1420176360', '1');
INSERT INTO `verified` VALUES ('135', '60419', '21028551121212', '陈良', '605956222@qq.com', '13513112212', '1420176705', '1');
INSERT INTO `verified` VALUES ('136', '60159', null, null, '', null, '1420189429', null);
INSERT INTO `verified` VALUES ('137', '60103', '21028116650102', '王枫', null, null, '1420254247', null);
INSERT INTO `verified` VALUES ('144', '43366', '21028119960203', '高振强', '827028140@qq.com', '13555999548', '1422514750', '1');
INSERT INTO `verified` VALUES ('145', '43367', '21028119550203', '刘云鹏', '53649092@qq.com', '13558454231', '1422515295', '1');
INSERT INTO `verified` VALUES ('146', '33370', '21028119950502', '郭俊州', 'gjz0931@yahoo.com.cn', '', '1422515546', '1');
INSERT INTO `verified` VALUES ('147', '85843', '21028119950501', '孙国军', '2481268332@qq.com', '13555456454', '1422613883', '1');
INSERT INTO `verified` VALUES ('148', '85823', '21028119660501', '段文臣', 'dwcckloo@yeah.net', '13555645545', '1422674957', '1');
INSERT INTO `verified` VALUES ('149', '85761', '21028119650203', '赵晓兴', '40884854@qq.com', '13555464542', '1422675154', '1');
INSERT INTO `verified` VALUES ('150', '87808', '21028119930111', '张三丰', null, '13604942422', '1422853603', null);
INSERT INTO `verified` VALUES ('151', '60105', '21028119930111', '约翰', 'jitming8@yahoo.com', null, '1422857959', null);
INSERT INTO `verified` VALUES ('152', '44375', null, null, 'mar_kou_yan_g@63.com', null, '1422858052', null);
INSERT INTO `verified` VALUES ('153', '43364', null, null, '2630757579@qq.com', null, '1422927779', null);
INSERT INTO `verified` VALUES ('154', '44374', '21028119910201', '陈飞', '77864768@qq.com', '13555646854', '1422932167', '1');
INSERT INTO `verified` VALUES ('156', '87812', '21028119660210', '吴荣', '1930809324@qq.com', null, '1423826909', null);
INSERT INTO `verified` VALUES ('157', '87783', '21028119900201', '张三', null, '13605151212', '1423827186', null);
INSERT INTO `verified` VALUES ('158', '33379', null, null, 'duzhewei.dd@qq.com', null, '1428406330', null);
